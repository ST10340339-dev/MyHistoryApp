package com.example.myhistory

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private var age1 : TextView? = null
    private var display: TextView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        age1 = findViewById(R.id.edtAge)
        display = findViewById(R.id.tvOutput)

        val calculate = findViewById<Button>(R.id.btnGenerate)
        val clear = findViewById<Button>(R.id.btnClear)

        calculate.setOnClickListener {
            generate()
        }
        clear.setOnClickListener {
            clear()
        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

    }

    private fun inputEmpty(): Boolean {
        var b = true
        if (age1?.text.toString().trim().isEmpty()){
            age1?.error = "Please enter a age"
            b = false
        }
        return b
    }

    private fun generate(){
        if(inputEmpty()){
            val input = age1?.text.toString().trim().toInt()

            if(input<20 || input>100){
                age1?.error = "The age you entered is invalid"
            }
            else {

                if (input >= 20 && input < 30 && input == 28) {
                    display?.text =
                        "You are $input years old, did you know that Health Ledger \n " +
                                "the person who played the joker died at the same age"
                } else {
                    display?.text =
                        "You are $input years old, the is no historical figure in your age that passed on "
                }
                if (input >= 20 && input < 30 && input == 22) {
                    display?.text = "You are $input years old, did you know that Aaliyah \n " +
                            "the person who played in Romeo Must Die died at the same age"
                } else {
                    display?.text =
                        "You are $input years old, the is no historical figure in your age that passed on "
                }

                if (input >= 30 && input < 40 && input == 36) {
                    display?.text = "You are $input years old, did you know that Bob Marley \n " +
                            "he is one of the best Regae artists in the world died at the same age"
                } else {
                    display?.text =
                        "You are $input years old, the is no historical figure in your age that passed on "
                }
                if (input >= 30 && input < 40 && input == 38) {
                    display?.text =
                        "You are $input years old, did you know that John F. Kennedy \n " +
                                "one of the United States Of America presidents died at the same age"
                } else {
                    display?.text =
                        "You are $input years old, the is no historical figure in your age that passed on "
                }

                if (input >= 40 && input < 50 && input == 45) {
                    display?.text =
                        "You are $input years old, did you know that Freddie Mercury \n " +
                                "one the best historical artists died at the  same age"
                } else {
                    display?.text =
                        "You are $input years old, the is no historical figure in your age that passed on "
                }
                if (input >= 40 && input < 50 && input == 48) {
                    display?.text =
                        "You are $input years old, did you know that Whitney Houston \n " +
                                "the best american female artist died at the same age"
                } else {
                    display?.text =
                        "You are $input years old, the is no historical figure in your age that passed on "
                }

                if (input >= 50 && input < 60 && input == 50) {
                    display?.text = "You are $input years old, did you know that Bernie Mac \n " +
                            "an American comedian died at the same age"
                } else {
                    display?.text =
                        "You are $input years old, the is no historical figure in your age that passed on "
                }
                if (input >= 50 && input < 60 && input == 56) {
                    display?.text = "You are $input years old, did you know that Steve Jobs \n " +
                            "the founder of Apple passed on at the same age"
                } else {
                    display?.text =
                        "You are $input years old, the is no historical figure in your age that passed on "
                }

                if (input >= 60 && input < 70 && input == 63) {
                    display?.text =
                        "You are $input years old, did you know that Robin Williams \n " +
                                "the person who played in Mrs Doubtfire  died at the same age"
                } else {
                    display?.text =
                        "You are $input years old, the is no historical figure in your age that passed on "
                }
                if (input >= 60 && input < 70 && input == 60) {
                    display?.text =
                        "You are $input years old, did you know that Andrew Fletcher \n " +
                                " died at the same age"
                } else {
                    display?.text =
                        "You are $input years old, the is no historical figure in your age that passed on "
                }

                if (input >= 70 && input < 80 && input == 70) {
                    display?.text =
                        "You are $input years old, the is no historical figure in your age that passed on"
                } else {
                    display?.text =
                        "You are $input years old, the is no historical figure in your age that passed on "
                }
                if (input >= 70 && input < 80 && input == 75) {
                    display?.text =
                        "You are $input years old, the is no historical figure in your age that passed on"
                } else {
                    display?.text =
                        "You are $input years old, the is no historical figure in your age that passed on "
                }

                if (input >= 80 && input < 90 && input == 83) {
                    display?.text = "You are $input years old, did you know that Paul Newman \n " +
                            " died at the same age"
                } else {
                    display?.text =
                        "You are $input years old, the is no historical figure in your age that passed on "
                }
                if (input >= 80 && input < 90 && input == 86) {
                    display?.text = "You are $input years old, did you know that Maya Angelou \n " +
                            "a writer died at the same age"
                } else {
                    display?.text =
                        "You are $input years old, the is no historical figure in your age that passed on "
                }

                if (input >= 90 && input < 100 && input == 96) {
                    display?.text = "You are $input years old, did you know that Cicely Tyson \n " +
                            "died at the same age"
                } else {
                    display?.text =
                        "You are $input years old, the is no historical figure in your age that passed on "
                }
                if (input >= 90 && input < 100 && input == 97) {
                    display?.text = "You are $input years old, did you know that Doris Day \n " +
                            " died at the same age"
                } else {
                    display?.text =
                        "You are $input years old, the is no historical figure in your age that passed on "
                }

                if (input == 100) {
                    display?.text =
                        "You are $input years old, did you know that Strom Thurmond \n " +
                                " died at the same age"
                }
            }
        }
    }
    private fun clear(){
        age1?.text= ""
        display?.text= ""
    }

}